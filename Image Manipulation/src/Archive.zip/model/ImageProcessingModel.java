package model;

import model.image.Image;

/**
 * An interface that represents the methods needed for processing an image.
 */
public interface ImageProcessingModel {

  void addImage(String name, Image im);

  Image getImage(String name);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * red component of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image createRed(String name, String destName);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * green component of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image createGreen(String name, String destName);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * blue component of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image createBlue(String name, String destName);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * max value of the rgb values of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image createValue(String name, String destName);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * average of the rgb values of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image createIntensity(String name, String destName);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * max value of the rgb values of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image createLuma(String name, String destName);

  /**
   * Adds a new image to the HashMap where the image is the given image
   * flipped horizontally.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image flipHoriz(String name, String destName);

  /**
   * Adds a new image to the HashMap made up of the value of the
   * max value of the rgb values of the given image for all the rgb values.
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image flipVert(String name, String destName);

  /**
   * Adds a new image to the HashMap where the image is
   * the given image with the interval added to each component
   * for all the rgb values.
   * If the component goes above the max value, it is set to the max value.
   * @param brightness the number by which each component increases
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image brighten(int brightness, String name, String destName);

  /**
   * Adds a new image to the HashMap where the image is
   * the given image with the interval subtracted from each component
   * for all the rgb values.
   * If the component goes below zero, it is set to zero.
   * @param darkness the number by which each component decreases
   * @param name the name of the given image
   * @param destName the name of the new image
   * @return the image added
   */
  Image darken(int darkness, String name, String destName);

  Image greyScale(String name, String destName);

  Image sepia(String name, String destName);

  Image blur(String name, String destName);

  Image sharpen(String name, String destName);
}

