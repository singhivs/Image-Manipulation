//package model.imageio;
//
//import java.awt.*;
//import java.awt.image.ImageObserver;
//import java.awt.image.ImageProducer;
//
//import model.image.Color;
//import model.image.OurImage;
//
//public class ImageImageModel extends Image implements OurImage{
//
//  public ImageImageModel() {
//    super();
//  }
//
//  @Override
//  public int getWidth(ImageObserver observer) {
//    return this.width;
//  }
//
//  @Override
//  public int getHeight(ImageObserver observer) {
//    return 0;
//  }
//
//  @Override
//  public ImageProducer getSource() {
//    return null;
//  }
//
//  @Override
//  public Graphics getGraphics() {
//    return null;
//  }
//
//  @Override
//  public Object getProperty(String name, ImageObserver observer) {
//    return null;
//  }
//
//  @Override
//  public int getWidth() {
//    return 0;
//  }
//
//  @Override
//  public int getHeight() {
//    return 0;
//  }
//
//  @Override
//  public int getMaxVal() {
//    return 0;
//  }
//
//  @Override
//  public Color[][] getColors() {
//    return new Color[0][];
//  }
//
//  @Override
//  public String getPath() {
//    return null;
//  }
//}
